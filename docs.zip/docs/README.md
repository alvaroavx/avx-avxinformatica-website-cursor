# Documentación — AVX Vector Field

La ruta canónica del juego es `src/`.

- Entrada: `src/index.html`.
- Inicio JavaScript: `src/js/main.js`.
- Mecánica de la partida: `src/js/game/game-controller.js`.
- Estilos: `src/styles/`.

## Configuración implementada

`GameController` define y persiste la personalización local del jugador:

- **Tema:** `green` (predeterminado, Verde AVX), `cyan` (Celeste), `pink` (Rosado) y `yellow` (Amarillo). El cambio actualiza Canvas y toda la interfaz de mando: HUD, paneles, botones, controles y foco.
- **Dificultad:** `easy` (4 vidas, menos rocas y menor velocidad), `normal` (3 vidas y balance estándar) y `hard` (2 vidas, más rocas y mayor velocidad). Se aplica cuando empieza una misión nueva.

Ambas elecciones viven exclusivamente en `localStorage` como `avx-vector-field-theme` y `avx-vector-field-difficulty`. Configuración se abre desde el menú principal o desde pausa; al abrirla durante una partida, esta sigue detenida.

Los documentos dentro de `archive/`, `planning/`, `experience/`, `product/` y `technical/` describen la antigua propuesta de sitio corporativo y se conservan solo como registro histórico. No deben utilizarse para desarrollar el juego actual ni como referencia de estructura: algunas rutas antiguas aún mencionan `avx-home/`, pero el directorio fue renombrado definitivamente a `src/`.
